/*
 * Question 3 – Dynamic Programming
 * Longest Palindromic Subsequence (LPS)
 *
 * Problem:
 *   Given a string S of length n, find the longest subsequence
 *   (not necessarily contiguous) that is a palindrome.
 *
 * Optimal Substructure & Recurrence:
 *   Let dp[i][j] = length of LPS in S[i..j].
 *
 *   Base cases:
 *     dp[i][i] = 1            (single character is a palindrome)
 *
 *   Recurrence:
 *     if S[i] == S[j]:  dp[i][j] = dp[i+1][j-1] + 2
 *     else:             dp[i][j] = max(dp[i+1][j], dp[i][j-1])
 *
 * Answer: dp[0][n-1]
 *
 * Time Complexity:  O(n²)  — fills an n×n table
 * Space Complexity: O(n²)  — the DP table
 *                   O(n)   — if we optimise to two rolling rows
 *                   O(n)   — recursion depth for traceback
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* ── Helpers ────────────────────────────────────────────────── */

static inline int max2(int a, int b) { return a > b ? a : b; }

/* ── Build DP table ─────────────────────────────────────────── */

/*
 * Allocates and fills the n×n dp table.
 * Caller is responsible for freeing: free(dp[0]); free(dp);
 */
int **build_dp(const char *S, int n)
{
    /* Allocate contiguous block for cache efficiency */
    int *data = malloc(n * n * sizeof(int));
    int **dp = malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++)
        dp[i] = data + i * n;

    /* Base case: single characters */
    for (int i = 0; i < n; i++)
        dp[i][i] = 1;

    /* Fill by increasing substring length */
    for (int len = 2; len <= n; len++)
    {
        for (int i = 0; i <= n - len; i++)
        {
            int j = i + len - 1;
            if (S[i] == S[j])
            {
                dp[i][j] = (len == 2) ? 2 : dp[i + 1][j - 1] + 2;
            }
            else
            {
                dp[i][j] = max2(dp[i + 1][j], dp[i][j - 1]);
            }
        }
    }
    return dp;
}

/* ── Traceback: reconstruct the actual LPS ──────────────────── */

/*
 * Fills result[] (must have space for n+1 chars) with the LPS.
 * Uses a two-pointer approach on the already-computed dp table.
 */
void traceback(const char *S, int **dp, int n, char *result)
{
    int i = 0, j = n - 1;
    int lo = 0, hi = dp[0][n - 1] - 1; /* write positions */
    result[dp[0][n - 1]] = '\0';

    while (i <= j)
    {
        if (i == j)
        {
            result[lo] = S[i];
            break;
        }
        if (S[i] == S[j])
        {
            result[lo] = S[i];
            result[hi] = S[j];
            lo++;
            hi--;
            i++;
            j--;
        }
        else if (dp[i + 1][j] > dp[i][j - 1])
        {
            i++;
        }
        else
        {
            j--;
        }
    }
}

/* ── Print DP table (small strings only) ────────────────────── */

void print_dp_table(const char *S, int **dp, int n)
{
    printf("     ");
    for (int j = 0; j < n; j++)
        printf("  %c", S[j]);
    printf("\n");
    for (int i = 0; i < n; i++)
    {
        printf("  %c  ", S[i]);
        for (int j = 0; j < n; j++)
        {
            if (j < i)
                printf("  .");
            else
                printf("  %d", dp[i][j]);
        }
        printf("\n");
    }
}

/* ── Main ───────────────────────────────────────────────────── */

int main(void)
{
    srand((unsigned)time(NULL));

    /* ── Example 1 ── */
    {
        const char *S = "BBABCBCAB";
        int n = (int)strlen(S);
        printf("=== Example 1 ===\n");
        printf("Input string : %s  (length %d)\n\n", S, n);

        int **dp = build_dp(S, n);

        printf("DP Table:\n");
        print_dp_table(S, dp, n);

        int lps_len = dp[0][n - 1];
        printf("\nLPS length: %d\n", lps_len);

        char *lps_str = malloc((lps_len + 1) * sizeof(char));
        traceback(S, dp, n, lps_str);
        printf("LPS string : %s\n", lps_str);

        free(lps_str);
        free(dp[0]);
        free(dp);
    }

    /* ── Example 2 ── */
    {
        const char *S = "AGBDBA";
        int n = (int)strlen(S);
        printf("\n=== Example 2 ===\n");
        printf("Input string : %s  (length %d)\n", S, n);

        int **dp = build_dp(S, n);
        int lps_len = dp[0][n - 1];
        printf("LPS length: %d\n", lps_len);

        char *lps_str = malloc((lps_len + 1) * sizeof(char));
        traceback(S, dp, n, lps_str);
        printf("LPS string : %s\n", lps_str);

        free(lps_str);
        free(dp[0]);
        free(dp);
    }

    /* ── Benchmark on large strings ── */
    printf("\n=== Benchmark ===\n");
    int sizes[] = {100, 500, 1000, 2000, 3000};
    int num_sizes = (int)(sizeof sizes / sizeof sizes[0]);
    const char alphabet[] = "ACGT"; /* DNA-like strings */

    for (int t = 0; t < num_sizes; t++)
    {
        int n = sizes[t];
        char *S = malloc((n + 1) * sizeof(char));
        for (int i = 0; i < n; i++)
            S[i] = alphabet[rand() % 4];
        S[n] = '\0';

        clock_t start = clock();
        int **dp = build_dp(S, n);
        int lps_len = dp[0][n - 1];
        clock_t end = clock();

        printf("n = %4d  ->  LPS length = %4d  |  time = %.4f s\n",
               n, lps_len, (double)(end - start) / CLOCKS_PER_SEC);

        free(dp[0]);
        free(dp);
        free(S);
    }

    printf("\nTime  Complexity: O(n^2)\n");
    printf("Space Complexity: O(n^2)  [table]  /  O(n) [two-row optimisation]\n");

    return 0;
}

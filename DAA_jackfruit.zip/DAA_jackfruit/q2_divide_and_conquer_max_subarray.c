/*
 * Question 2 – Divide and Conquer
 * Maximum Subarray Sum (Kadane comparison included)
 *
 * Problem:
 *   Given an array A[0..n-1] of integers, find the contiguous
 *   subarray with the maximum sum.
 *
 * Divide-and-Conquer Approach:
 *   Split the array at the midpoint.  The maximum subarray is either:
 *     (a) Entirely in the LEFT  half  → recurse left
 *     (b) Entirely in the RIGHT half  → recurse right
 *     (c) CROSSING the midpoint       → computed in O(n)
 *   Take the maximum of (a), (b), (c).
 *
 * Recurrence:
 *   T(n) = 2·T(n/2) + Θ(n)
 *   By Master Theorem (case 2):  T(n) = Θ(n log n)
 *
 * Kadane's Algorithm:
 *   Single linear scan → Θ(n).  Better asymptotically.
 *
 * Space Complexity: O(log n) stack depth for D&C; O(1) for Kadane.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

/* ── Helpers ────────────────────────────────────────────────── */

static inline int max2(int a, int b) { return a > b ? a : b; }
static inline int max3(int a, int b, int c) { return max2(max2(a, b), c); }

/* ── Result type ────────────────────────────────────────────── */

typedef struct
{
    int sum; /* maximum subarray sum          */
    int lo;  /* inclusive left  index         */
    int hi;  /* inclusive right index         */
} SubarrayResult;

/* ── Crossing subarray ──────────────────────────────────────── */

SubarrayResult max_crossing(const int *A, int lo, int mid, int hi)
{
    /* Expand left from mid */
    int left_sum = INT_MIN, sum = 0, best_lo = mid;
    for (int i = mid; i >= lo; i--)
    {
        sum += A[i];
        if (sum > left_sum)
        {
            left_sum = sum;
            best_lo = i;
        }
    }

    /* Expand right from mid+1 */
    int right_sum = INT_MIN;
    sum = 0;
    int best_hi = mid + 1;
    for (int j = mid + 1; j <= hi; j++)
    {
        sum += A[j];
        if (sum > right_sum)
        {
            right_sum = sum;
            best_hi = j;
        }
    }

    SubarrayResult r = {left_sum + right_sum, best_lo, best_hi};
    return r;
}

/* ── Divide and Conquer ─────────────────────────────────────── */

SubarrayResult max_subarray_dc(const int *A, int lo, int hi)
{
    /* Base case: single element */
    if (lo == hi)
    {
        SubarrayResult r = {A[lo], lo, lo};
        return r;
    }

    int mid = (lo + hi) / 2;

    SubarrayResult left = max_subarray_dc(A, lo, mid);
    SubarrayResult right = max_subarray_dc(A, mid + 1, hi);
    SubarrayResult crossing = max_crossing(A, lo, mid, hi);

    /* Return whichever is largest */
    if (left.sum >= right.sum && left.sum >= crossing.sum)
        return left;
    if (right.sum >= left.sum && right.sum >= crossing.sum)
        return right;
    return crossing;
}

/* ── Kadane's Algorithm  O(n) ───────────────────────────────── */

SubarrayResult kadane(const int *A, int n)
{
    SubarrayResult best = {A[0], 0, 0};
    int cur_sum = A[0], cur_lo = 0;

    for (int i = 1; i < n; i++)
    {
        if (cur_sum + A[i] < A[i])
        {
            cur_sum = A[i];
            cur_lo = i;
        }
        else
        {
            cur_sum += A[i];
        }
        if (cur_sum > best.sum)
        {
            best.sum = cur_sum;
            best.lo = cur_lo;
            best.hi = i;
        }
    }
    return best;
}

/* ── Print array ────────────────────────────────────────────── */

void print_array(const int *A, int n)
{
    for (int i = 0; i < n; i++)
        printf("%4d", A[i]);
    printf("\n");
}

/* ── Main ───────────────────────────────────────────────────── */

int main(void)
{
    srand((unsigned)time(NULL));

    /* ── Small example ── */
    printf("=== Small Example ===\n");
    int A[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    int n = (int)(sizeof A / sizeof A[0]);

    printf("Array: ");
    print_array(A, n);

    SubarrayResult dc = max_subarray_dc(A, 0, n - 1);
    printf("Divide & Conquer -> sum = %d, indices [%d, %d]\n",
           dc.sum, dc.lo, dc.hi);

    SubarrayResult kd = kadane(A, n);
    printf("Kadane           -> sum = %d, indices [%d, %d]\n",
           kd.sum, kd.lo, kd.hi);

    /* ── Verification on random arrays ── */
    printf("\n=== Correctness Verification (1000 random arrays) ===\n");
    int mismatches = 0;
    for (int t = 0; t < 1000; t++)
    {
        int sz = 1 + rand() % 200;
        int *B = malloc(sz * sizeof(int));
        for (int i = 0; i < sz; i++)
            B[i] = (rand() % 201) - 100; /* [-100,100] */

        SubarrayResult r_dc = max_subarray_dc(B, 0, sz - 1);
        SubarrayResult r_kd = kadane(B, sz);
        if (r_dc.sum != r_kd.sum)
            mismatches++;
        free(B);
    }
    printf("Mismatches: %d / 1000\n", mismatches);

    /* ── Benchmark ── */
    printf("\n=== Benchmark: D&C vs Kadane ===\n");
    int sizes[] = {1000, 10000, 100000, 500000};
    int num_sizes = (int)(sizeof sizes / sizeof sizes[0]);

    for (int t = 0; t < num_sizes; t++)
    {
        int sz = sizes[t];
        int *C = malloc(sz * sizeof(int));
        for (int i = 0; i < sz; i++)
            C[i] = (rand() % 2001) - 1000;

        clock_t s1 = clock();
        SubarrayResult r1 = max_subarray_dc(C, 0, sz - 1);
        clock_t e1 = clock();

        clock_t s2 = clock();
        SubarrayResult r2 = kadane(C, sz);
        clock_t e2 = clock();

        (void)r1;
        (void)r2; /* suppress unused-variable warnings */

        printf("n = %7d  |  D&C: %.4f s  |  Kadane: %.4f s\n",
               sz,
               (double)(e1 - s1) / CLOCKS_PER_SEC,
               (double)(e2 - s2) / CLOCKS_PER_SEC);
        free(C);
    }

    printf("\nRecurrence:  T(n) = 2T(n/2) + theta(n)  ->  theta(n log n)\n");
    printf("Kadane:      T(n) = theta(n)\n");

    return 0;
}

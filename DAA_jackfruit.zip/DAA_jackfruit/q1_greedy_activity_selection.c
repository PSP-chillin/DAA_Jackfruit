/*
 * Question 1 – Greedy Method
 * Activity Selection Problem
 *
 * Problem:
 *   Given n activities with start time s_i and finish time f_i,
 *   select the maximum number of non-overlapping activities.
 *
 * Greedy Strategy:
 *   Always pick the activity with the earliest finish time that
 *   does not overlap with the last selected activity.
 *
 *   Justification (Exchange Argument):
 *   Suppose an optimal solution does NOT include the activity
 *   with the earliest finish time. We can always swap in that
 *   activity without reducing the count, because its finish time
 *   is ≤ every other activity's finish time, leaving at least as
 *   much room for future activities.
 *
 * Time Complexity:
 *   - Sorting:  O(n log n)
 *   - Selection: O(n)
 *   - Total:    O(n log n)
 *
 * Space Complexity: O(n)
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* ── Data structure ─────────────────────────────────────────── */

typedef struct
{
    int id;
    int start;
    int finish;
} Activity;

/* ── Comparator: sort by finish time ascending ──────────────── */

int cmp_finish(const void *a, const void *b)
{
    const Activity *x = (const Activity *)a;
    const Activity *y = (const Activity *)b;
    return x->finish - y->finish;
}

/* ── Greedy selection ───────────────────────────────────────── */

/*
 * Returns the number of selected activities.
 * selected[] is filled with indices (into the sorted array).
 */
int activity_selection(Activity *acts, int n, int *selected)
{
    if (n == 0)
        return 0;

    /* Sort by finish time */
    qsort(acts, n, sizeof(Activity), cmp_finish);

    int count = 0;
    selected[count++] = 0; /* Always pick the first one */
    int last = 0;          /* Index of last picked activity */

    for (int i = 1; i < n; i++)
    {
        /* Activity i is compatible if it starts after last finishes */
        if (acts[i].start >= acts[last].finish)
        {
            selected[count++] = i;
            last = i;
        }
    }
    return count;
}

/* ── Utility: generate random activities ───────────────────── */

void generate_activities(Activity *acts, int n, int max_time)
{
    for (int i = 0; i < n; i++)
    {
        int s = rand() % max_time;
        int f = s + 1 + rand() % 20; /* finish > start */
        if (f > max_time)
            f = max_time;
        acts[i].id = i + 1;
        acts[i].start = s;
        acts[i].finish = f;
    }
}

/* ── Print helpers ──────────────────────────────────────────── */

void print_activities(const Activity *acts, int n)
{
    printf("%-6s %-8s %-8s\n", "ID", "Start", "Finish");
    printf("%-6s %-8s %-8s\n", "---", "-----", "------");
    for (int i = 0; i < n; i++)
        printf("%-6d %-8d %-8d\n", acts[i].id, acts[i].start, acts[i].finish);
}

/* ── Main ───────────────────────────────────────────────────── */

int main(void)
{
    srand((unsigned)time(NULL));

    /* ── Small manual example ── */
    printf("=== Small Example ===\n");
    Activity small[] = {
        {1, 1, 4}, {2, 3, 5}, {3, 0, 6}, {4, 5, 7}, {5, 3, 9}, {6, 5, 9}, {7, 6, 10}, {8, 8, 11}, {9, 8, 12}, {10, 2, 14}};
    int n_small = (int)(sizeof small / sizeof small[0]);

    printf("Input activities:\n");
    print_activities(small, n_small);

    int *sel_small = malloc(n_small * sizeof(int));
    int cnt_small = activity_selection(small, n_small, sel_small);

    printf("\nSelected %d activities (after sorting by finish time):\n", cnt_small);
    for (int i = 0; i < cnt_small; i++)
        printf("  Activity ID %d  [%d, %d)\n",
               small[sel_small[i]].id,
               small[sel_small[i]].start,
               small[sel_small[i]].finish);
    free(sel_small);

    /* ── Large random benchmark ── */
    printf("\n=== Large Random Input Benchmark ===\n");
    int sizes[] = {1000, 10000, 100000, 1000000};
    int num_sizes = (int)(sizeof sizes / sizeof sizes[0]);

    for (int t = 0; t < num_sizes; t++)
    {
        int n = sizes[t];
        Activity *acts = malloc(n * sizeof(Activity));
        int *sel = malloc(n * sizeof(int));

        generate_activities(acts, n, n * 10);

        clock_t start = clock();
        int cnt = activity_selection(acts, n, sel);
        clock_t end = clock();

        double elapsed = (double)(end - start) / CLOCKS_PER_SEC;
        printf("n = %7d  ->  selected = %7d  |  time = %.4f s\n",
               n, cnt, elapsed);

        free(acts);
        free(sel);
    }

    return 0;
}
